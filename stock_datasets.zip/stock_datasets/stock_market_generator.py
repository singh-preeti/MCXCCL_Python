"""
Stock Market Random Data Generator
Generates 1,000+ rows of fictional stock-market data and saves them to CSV.

Install dependency:
    pip install pandas

Run:
    python stock_market_generator.py
"""

import random
import pandas as pd

def generate_stock_data(rows=1500, output_file="stock_market_data.csv"):
    random.seed()  # Different random data each run

    companies = {
        "RELIANCE": ("Reliance Industries", 1400),
        "TCS": ("Tata Consultancy Services", 3800),
        "INFY": ("Infosys", 1500),
        "HDFCBANK": ("HDFC Bank", 1700),
        "ICICIBANK": ("ICICI Bank", 1200),
        "ITC": ("ITC Limited", 450),
        "SBIN": ("State Bank of India", 800),
        "WIPRO": ("Wipro", 500),
        "LT": ("Larsen & Toubro", 3500),
        "BHARTIARTL": ("Bharti Airtel", 1800),
    }

    trading_dates = pd.date_range("2025-01-01", "2026-10-01", freq="B")
    symbols = list(companies.keys())
    records = []

    for trade_id in range(1, rows + 1):
        symbol = random.choice(symbols)
        company, base_price = companies[symbol]
        date = random.choice(trading_dates)

        previous_close = base_price * random.uniform(0.85, 1.15)
        open_price = previous_close * random.uniform(0.985, 1.015)
        close_price = open_price * random.uniform(0.97, 1.03)
        high_price = max(open_price, close_price) * random.uniform(1.000, 1.025)
        low_price = min(open_price, close_price) * random.uniform(0.975, 1.000)
        volume = random.randint(10_000, 5_000_000)

        change = close_price - previous_close
        change_percent = (change / previous_close) * 100

        records.append({
            "Trade_ID": trade_id,
            "Date": date.strftime("%Y-%m-%d"),
            "Symbol": symbol,
            "Company": company,
            "Open": round(open_price, 2),
            "High": round(high_price, 2),
            "Low": round(low_price, 2),
            "Close": round(close_price, 2),
            "Previous_Close": round(previous_close, 2),
            "Volume": volume,
            "Price_Change": round(change, 2),
            "Change_Percent": round(change_percent, 2),
        })

    df = pd.DataFrame(records)
    df = df.sort_values(["Date", "Symbol"]).reset_index(drop=True)
    df.to_csv(output_file, index=False)
    print(f"Success! Generated {len(df)} rows.")
    print(f"CSV saved to: {output_file}")
    print("\\nFirst 5 rows:")
    print(df.head())
    return df

if __name__ == "__main__":
    number_of_rows = input("How many rows do you want? (minimum 1000, default 1500): ").strip()
    try:
        number_of_rows = int(number_of_rows) if number_of_rows else 1500
    except ValueError:
        number_of_rows = 1500

    if number_of_rows < 1000:
        print("Minimum is 1000 rows. Generating 1000 rows instead.")
        number_of_rows = 1000

    generate_stock_data(number_of_rows)
